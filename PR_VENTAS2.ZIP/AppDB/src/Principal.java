/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Principal {

    public static void main(String[] args) {
        String driver = "com.mysql.cj.jdbc.Driver";
        String URL_bd = "jdbc:mysql://localhost:3306/pr_ventas";
        String usuario = "root";
        String clave = "";
        Connection con = null;
        Statement comando = null;
        ResultSet registros = null;
        String sql;
        int filas_afectadas;
            try {
                Class.forName(driver);
                con = DriverManager.getConnection(URL_bd, usuario, clave);
                if(con != null){
                    System.out.println("Conexión exitosa");
                    comando = con.createStatement();
                    //sql = "select nombre, costo from tbl_proyecto;";
                    //sql = "UPDATE tbl_lugar SET codigo = 2 WHERE codigo = 3;";
                    //filas_afectadas = comando.executeUpdate(sql);
                    //System.out.println("Se afectaron " + filas_afectadas + " registros");
                    sql="select * from empleado";
                    registros = comando.executeQuery(sql);
                    while(registros.next()){
                        Scanner R = new Scanner(System.in);
                        System.out.println("QUE DESEA REVISAR?");
                        System.out.println("1 = Empleado");
                        System.out.println("2 = Equipos");
                        System.out.println("3 = Proveedor");
                        System.out.println("4 = Cliente");
                        int respuesta = R.nextInt();
                        if(respuesta==1){
                            System.out.println("--------------Empleado--------------");
                            System.out.println("ID:" + registros.getInt("id_empleado"));
                            System.out.println("Nombre" + registros.getString("Nombre"));
                            System.out.println("edad:" + registros.getInt("edad"));
                            System.out.println("celular:" + registros.getString("celular"));
                        }
                        if(respuesta==2){
                            System.out.println("--------------Equipos--------------");
                            System.out.println("ID: " + registros.getInt("id_producto"));
                            System.out.println("Nombre " + registros.getString("Nombre_producto"));
                            System.out.println("Cantidad: " + registros.getFloat("Cantidad"));
                            System.out.println("Valor entrada unitario: " + registros.getFloat("Valor_entrada_unitario"));
                            System.out.println("Valor salida unitario: " + registros.getFloat("Valor_salida_unitario"));
                        }
                        if(respuesta==3){
                            System.out.println("--------------Proveedor--------------");
                            System.out.println("ID: " + registros.getInt("id_proveedor"));
                            System.out.println("Nombre " + registros.getString("nombre_vendedor"));
                            System.out.println("Celular: " + registros.getInt("Celular"));
                            System.out.println("VEmail: " + registros.getString("Email"));
                        }
                        if(respuesta==4){
                            System.out.println("--------------Cliente--------------");
                            System.out.println("ID: " + registros.getInt("id_cliente"));
                            System.out.println("Nombre " + registros.getString("Nombre_cliente"));
                        }
                    }
                    //sql = "INSERT INTO tbl_lugar(codigo, nombre) VALUES (null,'Salón 408');";
                    con.close();
                }else{
                    System.out.println("Conexión NO exitosa");
                }
            } 
        catch (ClassNotFoundException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
